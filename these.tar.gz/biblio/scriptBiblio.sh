#!/usr/bin/bash

cat ./tmp/*.bib > bibliography.bib
